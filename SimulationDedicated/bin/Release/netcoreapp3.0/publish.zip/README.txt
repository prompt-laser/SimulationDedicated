CLI Parameters

--objects
Number of objects to simulate

--threads
Number of threads to use. There's a fine balance between objects / thread. Generally don't use less than 100 objects / thread


Console Commands

tps
Ticks per second

object select x
Select object number x. This number must be greater than 0 and less than or equal to the number of objects being simulated

object select none
Deselect current object

object remove
Remove selected object

object add
Add a new object